package com.example.services.worker

import android.content.Context
import androidx.annotation.WorkerThread
import androidx.work.Data
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.services.type.Facts
import com.google.gson.Gson
import java.net.HttpURLConnection
import java.net.URL

class CatFactWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    private val ur = "https://catfact.ninja/facts?limit=15"

    @WorkerThread
    override fun doWork(): Result {
        var c: List<Facts> = emptyList()
        try {
            val url = URL(ur)
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.connectTimeout = 10000
            val response = connection.inputStream.bufferedReader().readText()
            connection.disconnect()
            val json = Gson().fromJson(response, Map::class.java)
            c = (json["data"] as List<Map<String, Any>>).map {
                Facts(
                    fact = it["fact"] as String,
                    length = (it["length"] as Double).toInt()
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        Thread.sleep(3000)
        val outputData = Data.Builder()
            .putString("catFacts", Gson().toJson(c))
            .build()
        return Result.success(outputData)
    }
}