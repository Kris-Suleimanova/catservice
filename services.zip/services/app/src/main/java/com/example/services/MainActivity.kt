package com.example.services

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.LiveData
import androidx.lifecycle.Observer
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.example.services.type.Facts
import com.example.services.viewmodel.View
import com.example.services.worker.CatFactWorker

import com.google.gson.Gson

class MainActivity : ComponentActivity() {
    private val viewModel: View by viewModels()
    private lateinit var receiver: BroadcastReceiver
    private lateinit var observer: Observer<WorkInfo>
    private lateinit var workInfo: LiveData<WorkInfo>
    private lateinit var navController: NavHostController
    private val request = OneTimeWorkRequest.Builder(CatFactWorker::class.java).build()



    @SuppressLint("InlinedApi")
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            navController = rememberNavController()
            MainScreen(navController, viewModel, request)
        }
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val catFacts = Gson().fromJson(
                    intent?.getStringExtra("catFacts"),
                    Array<Facts>::class.java
                ).toList()
                viewModel.updateCatFacts(catFacts)
                navController.navigate("s2")
            }
        }

        registerReceiver(receiver, IntentFilter("com.example.services"), Context.RECEIVER_EXPORTED)



        observer = Observer { workInfo ->
            if (workInfo.state == WorkInfo.State.SUCCEEDED) {
                val catFacts = Gson().fromJson(
                    workInfo.outputData.getString("catFacts"),
                    Array<Facts>::class.java
                ).toList()
                viewModel.updateCatFacts(catFacts)
                navController.navigate("s2")
            }
        }

        val workManager = WorkManager.getInstance(this)
        workInfo = workManager.getWorkInfoByIdLiveData(request.id)
        workInfo.observe(this, observer)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(receiver)
        workInfo.removeObserver(observer)
    }
}


@Composable
fun ScreenSelect(viewModel: View, request: OneTimeWorkRequest) {
    val context = LocalContext.current
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = stringResource(R.string.select),
            fontSize = 20.sp,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            fontFamily= FontFamily.Serif,
            color = Color.Blue,
            fontStyle = FontStyle.Italic
        )
        Spacer(modifier = Modifier.height(200.dp))
        Button(
            onClick = { viewModel.service(context) },
            modifier = Modifier.width(100.dp),
            shape = CircleShape,
            border = BorderStroke(5.dp, Color.Black),
            colors = ButtonDefaults.buttonColors(Color(0xFFEB7D7D)),
            elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
            contentPadding = PaddingValues(16.dp)
        ) {
            Text(text = stringResource(R.string.service),
                fontSize = 15.sp,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                fontFamily= FontFamily.Serif,
                color = Color.Blue,
                fontStyle = FontStyle.Italic)
        }
        Spacer(modifier = Modifier.height(60.dp))
        Button(
            onClick = { viewModel.workManager(context, request) },
            modifier = Modifier.width(160.dp),
            shape = CircleShape,
            border = BorderStroke(5.dp, Color.Black),
            colors = ButtonDefaults.buttonColors(Color(0xFFEB7D7D)),
            elevation = ButtonDefaults.elevatedButtonElevation(8.dp),
            contentPadding = PaddingValues(16.dp)
        ) {
            Text(text = stringResource(R.string.workmanager),
                fontSize = 15.sp,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                fontFamily= FontFamily.Serif,
                color = Color.Blue,
                fontStyle = FontStyle.Italic)
        }
    }
}


@Composable
fun ScreenEnd(viewModel: View) {
    val catFacts by viewModel.catFacts.observeAsState(initial = emptyList())
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = stringResource(R.string.fact),
            fontSize = 20.sp,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            fontFamily= FontFamily.Serif,
            color = Color.Blue,
            fontStyle = FontStyle.Italic,
            textDecoration = TextDecoration.Underline)
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn {
            itemsIndexed(catFacts) { _, catFact ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    colors = CardDefaults.cardColors(Color(0xFFCCC2DC)),
                    elevation =  CardDefaults.cardElevation(20.dp),
                    shape = RoundedCornerShape(40.dp)
                ) {
                    Text(
                        text = catFact.fact,
                        modifier = Modifier.padding(16.dp),
                        fontSize = 15.sp,
                        style = MaterialTheme.typography.titleLarge,
                        fontFamily= FontFamily.Serif,
                        color = Color.Blue,
                        fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Italic
                    )
                }
            }
        }
    }
}

@Composable
fun MainScreen(navController: NavHostController, viewModel: View, request: OneTimeWorkRequest) {
    NavHost(navController = navController, startDestination = "s1") {
        composable("s1") {
            ScreenSelect(viewModel = viewModel, request)
        }
        composable("s2") {
            ScreenEnd(viewModel = viewModel)
        }
    }
}