package com.example.services.viewmodel

import android.content.Context
import android.content.Intent
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import com.example.services.provider.FactsProvider
import com.example.services.type.Facts
import kotlinx.coroutines.launch

class View : ViewModel() {
    private val _catFacts = MutableLiveData<List<Facts>>()
    val catFacts: LiveData<List<Facts>> = _catFacts

    fun service(context: Context) {
        viewModelScope.launch {
            val intent = Intent(context, FactsProvider::class.java)
            context.startService(intent)
        }
    }

    fun workManager(context: Context, request: OneTimeWorkRequest) {
        viewModelScope.launch {
            WorkManager.getInstance(context).enqueueUniqueWork("import",ExistingWorkPolicy.REPLACE,request)
        }
    }

    fun updateCatFacts(catFacts: List<Facts>) {
        _catFacts.value = catFacts
    }
}