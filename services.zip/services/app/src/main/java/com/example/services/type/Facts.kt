package com.example.services.type

data class Facts(
    val fact: String,
    val length: Int
)
